g++ -Wall -O2 -g -I.. -o test_partial_queue test_partial_queue.cc
