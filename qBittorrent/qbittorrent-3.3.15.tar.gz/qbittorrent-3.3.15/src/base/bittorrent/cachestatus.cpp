/*
 * Bittorrent Client using Qt and libtorrent.
 * Copyright (C) 2015  Vladimir Golovnev <glassez@yandex.ru>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 *
 * In addition, as a special exception, the copyright holders give permission to
 * link this program with the OpenSSL project's "OpenSSL" library (or with
 * modified versions of it that use the same license as the "OpenSSL" library),
 * and distribute the linked executables. You must obey the GNU General Public
 * License in all respects for all of the code used other than "OpenSSL".  If you
 * modify file(s), you may extend this exception to your version of the file(s),
 * but you are not obligated to do so. If you do not wish to do so, delete this
 * exception statement from your version.
 */

#include <libtorrent/version.hpp>
#include "cachestatus.h"

using namespace BitTorrent;

CacheStatus::CacheStatus(const libtorrent::cache_status &nativeStatus)
    : m_nativeStatus(nativeStatus)
{
}

int CacheStatus::totalUsedBuffers() const
{
    return m_nativeStatus.total_used_buffers;
}

qreal CacheStatus::readRatio() const
{
    if (m_nativeStatus.blocks_read > 0)
        return (static_cast<qreal>(m_nativeStatus.blocks_read_hit) / m_nativeStatus.blocks_read);
    else
        return -1;
}

int CacheStatus::jobQueueLength() const
{
#if LIBTORRENT_VERSION_NUM < 10100
    return m_nativeStatus.job_queue_length;
#else
    return m_nativeStatus.queued_jobs;
#endif
}

int CacheStatus::averageJobTime() const
{
    return m_nativeStatus.average_job_time;
}

qlonglong CacheStatus::queuedBytes() const
{
    return m_nativeStatus.queued_bytes;
}
