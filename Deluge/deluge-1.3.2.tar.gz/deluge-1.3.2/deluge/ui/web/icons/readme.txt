images from the fruge icon set.
See LICENSE for a list of icons not taken from fruge.
