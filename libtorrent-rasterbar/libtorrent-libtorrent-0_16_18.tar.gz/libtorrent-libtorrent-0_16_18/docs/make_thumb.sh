convert $1 -resize 150x130 $1

